library(schrute)


df <- schrute::theoffice

write.csv(df, "{my desktop}")
  